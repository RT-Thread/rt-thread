var group__lwip__opts__pbuf =
[
    [ "PBUF_LINK_ENCAPSULATION_HLEN", "group__lwip__opts__pbuf.html#ga6e1ba1875ae5168a17b53d83597bc1de", null ],
    [ "PBUF_LINK_HLEN", "group__lwip__opts__pbuf.html#ga35998a3d56af9940e6a80bb372597685", null ],
    [ "PBUF_POOL_BUFSIZE", "group__lwip__opts__pbuf.html#gae61f4491d56e805e79b79eb5d35a00e5", null ]
];