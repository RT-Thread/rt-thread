var api__lib_8c =
[
    [ "netconn_accept", "group__netconn__tcp.html#ga13593148f60f7bbc6a505b567f175d69", null ],
    [ "netconn_bind", "group__netconn__common.html#ga63bcc4d7bd150674fa953a1253fa6230", null ],
    [ "netconn_close", "group__netconn__tcp.html#ga25bb1c1c9928f91f53149a026e2e2624", null ],
    [ "netconn_connect", "group__netconn__common.html#gacba7f74d973872ad0b88b9a96098cf77", null ],
    [ "netconn_delete", "group__netconn__common.html#gab411221f912a6d9e4c82ac3963989403", null ],
    [ "netconn_disconnect", "group__netconn__udp.html#ga90bb4c4d1af6602a655b78fce0520402", null ],
    [ "netconn_getaddr", "api__lib_8c.html#a28430d1d86733f1bf98dc31305c42104", null ],
    [ "netconn_gethostbyname_addrtype", "group__netconn__common.html#gafb3494b149dff96ed8d1acb770ab52f5", null ],
    [ "netconn_join_leave_group", "group__netconn__udp.html#gaaaf2f92eeb38dca70b3e6ad98c3c45ed", null ],
    [ "netconn_listen_with_backlog", "group__netconn__tcp.html#ga84333ba8e7cdf45558d2b4795f53265d", null ],
    [ "netconn_new_with_proto_and_callback", "api__lib_8c.html#ad0a0434e5ff08bb350740cb840e2aca8", null ],
    [ "netconn_recv", "group__netconn__common.html#ga50490bab058f4e740798beffcf48cabf", null ],
    [ "netconn_recv_tcp_pbuf", "group__netconn__tcp.html#ga6893cb7648733d1f05696bac94e10490", null ],
    [ "netconn_send", "group__netconn__udp.html#gac4d4d10153d47c80a783c34b27c66238", null ],
    [ "netconn_sendto", "group__netconn__udp.html#ga8e1d852119bda1e1b602c2995282ef0c", null ],
    [ "netconn_shutdown", "group__netconn__tcp.html#ga6ec6b2cf7b0f59e9371e38ae7dea2a63", null ],
    [ "netconn_write_partly", "group__netconn__tcp.html#gacf9ce6f71652739d6be2ca83f7c423bf", null ]
];