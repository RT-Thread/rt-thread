var group__dhcp4 =
[
    [ "dhcp_cleanup", "group__dhcp4.html#ga292a1b0c0c288ec508108a3fba473e64", null ],
    [ "dhcp_inform", "group__dhcp4.html#gabd7fcc7e0799e313885fc7fd9d4992ad", null ],
    [ "dhcp_release", "group__dhcp4.html#gaf92f7afb58252f82a749064602974bd4", null ],
    [ "dhcp_renew", "group__dhcp4.html#ga583eb8d58f5e96b7dea717948578a947", null ],
    [ "dhcp_set_struct", "group__dhcp4.html#ga43812097832716a462c660eb59cc1bf8", null ],
    [ "dhcp_start", "group__dhcp4.html#ga0c50968d9811aa2aa67fadc0885d744f", null ],
    [ "dhcp_stop", "group__dhcp4.html#ga93f6bf21086dc9b10c0bec4676f97312", null ]
];