var group__slipif =
[
    [ "slipif_init", "group__slipif.html#ga687973ba82dab13a5b9d38d7399aeee3", null ],
    [ "slipif_poll", "group__slipif.html#ga7b036fd1cde9b299139cac62f52d15a6", null ],
    [ "slipif_process_rxqueue", "group__slipif.html#gae135be7d61e5bb49ab72476b0aa70946", null ],
    [ "slipif_received_byte", "group__slipif.html#ga3f2f5e2fa4a816dc27a46f3ee91cf1b3", null ],
    [ "slipif_received_bytes", "group__slipif.html#gabbee48569a513c90fe154632038eb6d6", null ]
];