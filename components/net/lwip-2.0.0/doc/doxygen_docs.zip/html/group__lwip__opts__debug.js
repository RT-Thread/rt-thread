var group__lwip__opts__debug =
[
    [ "Statistics", "group__lwip__opts__stats.html", "group__lwip__opts__stats" ],
    [ "Debugging", "group__lwip__opts__debugmsg.html", "group__lwip__opts__debugmsg" ],
    [ "Performance", "group__lwip__opts__perf.html", "group__lwip__opts__perf" ]
];