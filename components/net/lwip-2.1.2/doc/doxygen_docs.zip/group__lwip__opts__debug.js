var group__lwip__opts__debug =
[
    [ "Assertion handling", "group__lwip__assertions.html", "group__lwip__assertions" ],
    [ "Statistics", "group__lwip__opts__stats.html", "group__lwip__opts__stats" ],
    [ "Debug messages", "group__lwip__opts__debugmsg.html", "group__lwip__opts__debugmsg" ],
    [ "Performance", "group__lwip__opts__perf.html", "group__lwip__opts__perf" ]
];