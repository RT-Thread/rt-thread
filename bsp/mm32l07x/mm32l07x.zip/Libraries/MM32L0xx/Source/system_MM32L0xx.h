extern uint32_t SystemCoreClock;
extern void SystemInit(void);
