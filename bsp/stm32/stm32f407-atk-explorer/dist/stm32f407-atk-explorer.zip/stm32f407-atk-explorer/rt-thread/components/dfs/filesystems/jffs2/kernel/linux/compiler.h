#ifndef __LINUX_COMPILER_H__
#define __LINUX_COMPILER_H__

#define likely(x) (x)
#define unlikely(x) (x)

#endif /* __LINUX_COMPILER_H__ */
