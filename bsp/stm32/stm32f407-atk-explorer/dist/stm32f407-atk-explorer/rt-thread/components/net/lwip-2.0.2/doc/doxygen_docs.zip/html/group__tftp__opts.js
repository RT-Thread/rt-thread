var group__tftp__opts =
[
    [ "TFTP_DEBUG", "group__tftp__opts.html#ga2dd54a1d0c3006527b8a7a8604b81981", null ],
    [ "TFTP_MAX_FILENAME_LEN", "group__tftp__opts.html#ga8e975900b4397313f1a649ff76a3063b", null ],
    [ "TFTP_MAX_MODE_LEN", "group__tftp__opts.html#gaa8a449c25e37be757f5efccd422c9055", null ],
    [ "TFTP_MAX_RETRIES", "group__tftp__opts.html#ga6a01757ad942eb602e8a87e2be42d313", null ],
    [ "TFTP_PORT", "group__tftp__opts.html#gad9230620a5d3bb87a7ac280ff99875d1", null ],
    [ "TFTP_TIMEOUT_MSECS", "group__tftp__opts.html#ga36986e5465dc2ccb6184fc57f9a37d63", null ],
    [ "TFTP_TIMER_MSECS", "group__tftp__opts.html#ga3e6caacb3f4d43f780b2d68ffe4258ea", null ]
];