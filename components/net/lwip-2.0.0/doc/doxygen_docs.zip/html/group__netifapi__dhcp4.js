var group__netifapi__dhcp4 =
[
    [ "netifapi_dhcp_inform", "group__netifapi__dhcp4.html#ga4cb8477566239180d0a53b5ee79f418b", null ],
    [ "netifapi_dhcp_release", "group__netifapi__dhcp4.html#ga3b058ff8a20b7ce364d68fc97ae563ad", null ],
    [ "netifapi_dhcp_renew", "group__netifapi__dhcp4.html#ga4b539fcfbb253d572175797e7a5b42a1", null ],
    [ "netifapi_dhcp_start", "group__netifapi__dhcp4.html#ga200b42c361951864e8fdef8078730d57", null ],
    [ "netifapi_dhcp_stop", "group__netifapi__dhcp4.html#gaf7f34a081df720c08129878217fa2116", null ]
];