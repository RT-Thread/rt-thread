var group__sys__os =
[
    [ "Semaphores", "group__sys__sem.html", "group__sys__sem" ],
    [ "Mutexes", "group__sys__mutex.html", "group__sys__mutex" ],
    [ "Mailboxes", "group__sys__mbox.html", "group__sys__mbox" ],
    [ "Misc", "group__sys__misc.html", "group__sys__misc" ]
];