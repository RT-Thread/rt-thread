var group__netif__cd =
[
    [ "netif_get_client_data", "group__netif__cd.html#ga4bce01ddbf0fd70cb88431f773c91bc5", null ],
    [ "netif_set_client_data", "group__netif__cd.html#ga5ce61a277e1951183f7b7d03742c231f", null ],
    [ "netif_alloc_client_data_id", "group__netif__cd.html#ga55d62d43b5a9a5527f0116ec38369978", null ]
];