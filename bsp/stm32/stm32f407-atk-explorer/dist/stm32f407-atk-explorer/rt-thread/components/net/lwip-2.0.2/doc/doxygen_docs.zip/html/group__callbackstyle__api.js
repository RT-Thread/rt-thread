var group__callbackstyle__api =
[
    [ "DNS", "group__dns.html", "group__dns" ],
    [ "IP", "group__ip.html", "group__ip" ],
    [ "Network interface (NETIF)", "group__netif.html", "group__netif" ],
    [ "RAW", "group__raw__raw.html", "group__raw__raw" ],
    [ "TCP", "group__tcp__raw.html", "group__tcp__raw" ],
    [ "UDP", "group__udp__raw.html", "group__udp__raw" ],
    [ "Ethernet", "group__ethernet.html", "group__ethernet" ]
];