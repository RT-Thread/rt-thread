var group__netifapi__netif =
[
    [ "netifapi_netif_remove", "group__netifapi__netif.html#ga2e9ea2a055e0879ff1af6a5b09926e8b", null ],
    [ "netifapi_netif_set_default", "group__netifapi__netif.html#ga862d6cfa5d36b2c36d7b1671e8d95ccf", null ],
    [ "netifapi_netif_set_down", "group__netifapi__netif.html#ga70a72e1a22afa373ba26a3f2d3e28d29", null ],
    [ "netifapi_netif_set_up", "group__netifapi__netif.html#ga65e666c72d3068280e7bb96eb24999a2", null ],
    [ "netifapi_netif_add", "group__netifapi__netif.html#gacc063c5a3071e34eec7376651e35a519", null ],
    [ "netifapi_netif_set_addr", "group__netifapi__netif.html#ga31755ea6dbb213236bfce19bcbe8c973", null ]
];