var group__ip4addr =
[
    [ "IP4_ADDR_ANY", "group__ip4addr.html#gae920b6e81610a38cf9ada52118807eff", null ],
    [ "IP4_ADDR_ANY4", "group__ip4addr.html#gaa3f65a42b68149e96e618600b2ca2e42", null ],
    [ "IP4_ADDR_BROADCAST", "group__ip4addr.html#ga5efdf55ba72c2b1b5755b1fc6f559a1a", null ],
    [ "ip_2_ip4", "group__ip4addr.html#ga40f4b75f5db2664404890c02d3d89f3a", null ],
    [ "IP_ADDR4", "group__ip4addr.html#ga22481a97252af9ee6ba3a0a76c457409", null ],
    [ "IP_ADDR_ANY", "group__ip4addr.html#ga3e5e67b7292b156034560fef2202776c", null ],
    [ "IP_ADDR_BROADCAST", "group__ip4addr.html#gad546955e48dada78b552375b873f6986", null ],
    [ "ip_addr_copy_from_ip4", "group__ip4addr.html#gae950e97369131a9ead0f72c5eaa86d96", null ],
    [ "ip_addr_get_ip4_u32", "group__ip4addr.html#ga09c62e8a3bf599aa7f335e0ad0820e85", null ],
    [ "ip_addr_set_ip4_u32", "group__ip4addr.html#ga971516589980428bf51f37cefa4ddf66", null ],
    [ "IP_IS_V4", "group__ip4addr.html#ga5d936ae73fc9400a5d1db61caa75cfca", null ],
    [ "IP_IS_V4_VAL", "group__ip4addr.html#gace635272d0ab5a8925ad9859825cd8ec", null ],
    [ "IPADDR4_INIT", "group__ip4addr.html#ga712961e4d8fa1a47d36806beb2710c9a", null ]
];