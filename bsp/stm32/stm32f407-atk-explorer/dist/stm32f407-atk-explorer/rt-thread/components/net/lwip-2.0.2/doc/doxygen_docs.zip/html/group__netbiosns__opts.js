var group__netbiosns__opts =
[
    [ "NETBIOS_LWIP_NAME", "group__netbiosns__opts.html#ga468c2ae67a79ce082ee585a438f7373b", null ]
];