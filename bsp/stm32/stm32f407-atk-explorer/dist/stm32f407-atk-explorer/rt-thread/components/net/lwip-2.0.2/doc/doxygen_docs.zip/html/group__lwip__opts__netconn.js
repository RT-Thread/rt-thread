var group__lwip__opts__netconn =
[
    [ "LWIP_NETCONN", "group__lwip__opts__netconn.html#ga478041b8544461258f6961bf0f3c1a77", null ],
    [ "LWIP_NETCONN_FULLDUPLEX", "group__lwip__opts__netconn.html#ga7bfe8487a3abffdd9d6730977d22c406", null ],
    [ "LWIP_NETCONN_SEM_PER_THREAD", "group__lwip__opts__netconn.html#ga2543345adf7d2c307df78a54ac2ba8c4", null ],
    [ "LWIP_TCPIP_TIMEOUT", "group__lwip__opts__netconn.html#ga1cd8d15a42262a0defaedabed126ea99", null ]
];